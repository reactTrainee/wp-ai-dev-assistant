jQuery(function ($) {
    $('#wpaida-analyze').on('click', function () {
        const button = $(this);
        const prompt = $('#wpaida-prompt').val().trim();
        const status = $('#wpaida-status');
        const result = $('#wpaida-result');

        if (prompt.length < 5) {
            status.text('Please enter a problem or error.');
            return;
        }

        button.prop('disabled', true);
        status.text('Analyzing…');
        result.html('<p>Claude is analyzing the information…</p>');

        $.post(wpaida.ajaxUrl, {
            action: 'wpaida_analyze',
            nonce: wpaida.nonce,
            prompt: prompt
        })
        .done(function (response) {
            if (response.success) {
                result.html(response.data.result);
                status.text('Analysis complete.');
            } else {
                result.html('<p><strong>Error:</strong> ' + escapeHtml(response.data.message) + '</p>');
                status.text('Request failed.');
            }
        })
        .fail(function (xhr) {
            let message = 'Request failed.';
            if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                message = xhr.responseJSON.data.message;
            }
            result.html('<p><strong>Error:</strong> ' + escapeHtml(message) + '</p>');
            status.text('Request failed.');
        })
        .always(function () {
            button.prop('disabled', false);
        });
    });

    function escapeHtml(text) {
        return $('<div>').text(text || '').html();
    }
});
