<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPAIDA_API {
    const ENDPOINT = 'https://api.anthropic.com/v1/messages';

    public static function ask( $user_prompt ) {
        $settings = WPAIDA_Settings::get();

        if ( empty( $settings['api_key'] ) ) {
            return new WP_Error(
                'missing_api_key',
                'Claude API key is not configured. Go to WP AI Dev Assistant → Settings.'
            );
        }

        $system = "You are an expert WordPress developer and technical support assistant.
Analyze WordPress, PHP, JavaScript, CSS, hosting, plugin, theme, API, and database problems.
Give practical, safe guidance. Never recommend destructive database or filesystem operations without warning.
When code is useful, provide a minimal, production-conscious example.
Structure responses with: Diagnosis, Likely Cause, Recommended Fix, and Verification Steps.";

        $body = array(
            'model'      => $settings['model'],
            'max_tokens' => absint( $settings['max_tokens'] ),
            'system'     => $system,
            'messages'   => array(
                array(
                    'role'    => 'user',
                    'content' => $user_prompt,
                ),
            ),
        );

        $response = wp_remote_post(
            self::ENDPOINT,
            array(
                'timeout' => 90,
                'headers' => array(
                    'Content-Type'      => 'application/json',
                    'x-api-key'         => $settings['api_key'],
                    'anthropic-version' => '2023-06-01',
                ),
                'body'    => wp_json_encode( $body ),
            )
        );

        if ( is_wp_error( $response ) ) {
            return new WP_Error( 'request_failed', $response->get_error_message() );
        }

        $status = wp_remote_retrieve_response_code( $response );
        $raw    = wp_remote_retrieve_body( $response );
        $data   = json_decode( $raw, true );

        if ( $status < 200 || $status >= 300 ) {
            $message = isset( $data['error']['message'] ) ? $data['error']['message'] : 'Claude API request failed.';
            return new WP_Error( 'api_error', $message, array( 'status' => $status ) );
        }

        $text = '';
        if ( ! empty( $data['content'] ) && is_array( $data['content'] ) ) {
            foreach ( $data['content'] as $block ) {
                if ( isset( $block['type'], $block['text'] ) && 'text' === $block['type'] ) {
                    $text .= $block['text'];
                }
            }
        }

        if ( '' === trim( $text ) ) {
            return new WP_Error( 'empty_response', 'Claude returned an empty response.' );
        }

        return $text;
    }
}
