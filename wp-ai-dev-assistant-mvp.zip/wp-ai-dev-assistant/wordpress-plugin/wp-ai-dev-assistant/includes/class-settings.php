<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPAIDA_Settings {
    const OPTION = 'wpaida_settings';

    public static function init() {
        add_action( 'admin_init', array( __CLASS__, 'register' ) );
    }

    public static function register() {
        register_setting(
            'wpaida_settings_group',
            self::OPTION,
            array(
                'type'              => 'array',
                'sanitize_callback' => array( __CLASS__, 'sanitize' ),
                'default'           => array(),
            )
        );

        add_settings_section(
            'wpaida_api_section',
            'Claude API settings',
            function () {
                echo '<p>Configure the server-side Claude API connection. Your API key is never sent to the browser.</p>';
            },
            'wpaida-settings'
        );

        add_settings_field(
            'api_key',
            'Claude API key',
            array( __CLASS__, 'api_key_field' ),
            'wpaida-settings',
            'wpaida_api_section'
        );

        add_settings_field(
            'model',
            'Model',
            array( __CLASS__, 'model_field' ),
            'wpaida-settings',
            'wpaida_api_section'
        );

        add_settings_field(
            'max_tokens',
            'Maximum output tokens',
            array( __CLASS__, 'max_tokens_field' ),
            'wpaida-settings',
            'wpaida_api_section'
        );
    }

    public static function sanitize( $input ) {
        $old = get_option( self::OPTION, array() );
        $out = array();

        if ( isset( $input['api_key'] ) && '' !== trim( $input['api_key'] ) ) {
            $out['api_key'] = sanitize_text_field( $input['api_key'] );
        } elseif ( ! empty( $old['api_key'] ) ) {
            $out['api_key'] = $old['api_key'];
        } else {
            $out['api_key'] = '';
        }

        $out['model'] = isset( $input['model'] )
            ? sanitize_text_field( $input['model'] )
            : 'claude-sonnet-5-5';

        $tokens = isset( $input['max_tokens'] ) ? absint( $input['max_tokens'] ) : 4096;
        $out['max_tokens'] = min( max( $tokens, 256 ), 16384 );

        return $out;
    }

    public static function get() {
        $settings = get_option( self::OPTION, array() );
        return wp_parse_args(
            $settings,
            array(
                'api_key'    => '',
                'model'      => 'claude-sonnet-5-5',
                'max_tokens' => 4096,
            )
        );
    }

    public static function api_key_field() {
        $settings = self::get();
        printf(
            '<input type="password" class="regular-text" name="%1$s[api_key]" value="" autocomplete="new-password" placeholder="%2$s" />',
            esc_attr( self::OPTION ),
            esc_attr( ! empty( $settings['api_key'] ) ? 'API key already saved — leave blank to keep it' : 'sk-ant-...' )
        );
    }

    public static function model_field() {
        $settings = self::get();
        printf(
            '<input type="text" class="regular-text" name="%1$s[model]" value="%2$s" />',
            esc_attr( self::OPTION ),
            esc_attr( $settings['model'] )
        );
        echo '<p class="description">Use a current model ID supported by your Anthropic account. You can change this without editing the plugin.</p>';
    }

    public static function max_tokens_field() {
        $settings = self::get();
        printf(
            '<input type="number" min="256" max="16384" step="256" name="%1$s[max_tokens]" value="%2$d" />',
            esc_attr( self::OPTION ),
            absint( $settings['max_tokens'] )
        );
    }
}
