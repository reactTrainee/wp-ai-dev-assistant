<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPAIDA_Admin {
    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
        add_action( 'wp_ajax_wpaida_analyze', array( __CLASS__, 'ajax_analyze' ) );
    }

    public static function menu() {
        add_menu_page(
            'WP AI Dev Assistant',
            'WP AI Dev Assistant',
            'manage_options',
            'wpaida',
            array( __CLASS__, 'dashboard' ),
            'dashicons-superhero',
            58
        );

        add_submenu_page(
            'wpaida',
            'Settings',
            'Settings',
            'manage_options',
            'wpaida-settings',
            array( __CLASS__, 'settings' )
        );
    }

    public static function assets( $hook ) {
        if ( false === strpos( $hook, 'wpaida' ) ) {
            return;
        }

        wp_enqueue_style(
            'wpaida-admin',
            WPAIDA_URL . 'admin/css/admin.css',
            array(),
            WPAIDA_VERSION
        );

        wp_enqueue_script(
            'wpaida-admin',
            WPAIDA_URL . 'admin/js/admin.js',
            array( 'jquery' ),
            WPAIDA_VERSION,
            true
        );

        wp_localize_script(
            'wpaida-admin',
            'wpaida',
            array(
                'ajaxUrl' => admin_url( 'admin-ajax.php' ),
                'nonce'   => wp_create_nonce( 'wpaida_analyze' ),
            )
        );
    }

    public static function dashboard() {
        ?>
        <div class="wrap wpaida-wrap">
            <h1>WP AI Dev Assistant</h1>
            <p class="wpaida-lead">Analyze WordPress errors and development problems with Claude.</p>

            <div class="wpaida-card">
                <label for="wpaida-prompt"><strong>What do you need help with?</strong></label>
                <textarea id="wpaida-prompt" rows="12" placeholder="Paste a WordPress/PHP error, debug log excerpt, code, or describe the problem..."></textarea>

                <div class="wpaida-actions">
                    <button type="button" class="button button-primary button-large" id="wpaida-analyze">
                        Analyze with Claude
                    </button>
                    <span id="wpaida-status" aria-live="polite"></span>
                </div>
            </div>

            <div class="wpaida-card">
                <h2>AI response</h2>
                <div id="wpaida-result" class="wpaida-result">
                    <p>Your analysis will appear here.</p>
                </div>
            </div>
        </div>
        <?php
    }

    public static function settings() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        ?>
        <div class="wrap">
            <h1>WP AI Dev Assistant Settings</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'wpaida_settings_group' );
                do_settings_sections( 'wpaida-settings' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public static function ajax_analyze() {
        check_ajax_referer( 'wpaida_analyze', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => 'You do not have permission to use this tool.' ), 403 );
        }

        $prompt = isset( $_POST['prompt'] ) ? sanitize_textarea_field( wp_unslash( $_POST['prompt'] ) ) : '';

        if ( strlen( trim( $prompt ) ) < 5 ) {
            wp_send_json_error( array( 'message' => 'Please provide more detail.' ), 400 );
        }

        $result = WPAIDA_API::ask( $prompt );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ), 500 );
        }

        wp_send_json_success( array( 'result' => wp_kses_post( nl2br( esc_html( $result ) ) ) ) );
    }
}
