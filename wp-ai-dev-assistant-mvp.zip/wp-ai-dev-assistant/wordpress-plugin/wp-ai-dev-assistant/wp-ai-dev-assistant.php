<?php
/**
 * Plugin Name: WP AI Dev Assistant
 * Plugin URI: https://example.com/
 * Description: AI-powered WordPress troubleshooting and developer assistance using the Claude API.
 * Version: 0.1.0
 * Author: WP AI Dev Assistant
 * License: GPL-2.0-or-later
 * Text Domain: wp-ai-dev-assistant
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'WPAIDA_VERSION', '0.1.0' );
define( 'WPAIDA_FILE', __FILE__ );
define( 'WPAIDA_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPAIDA_URL', plugin_dir_url( __FILE__ ) );

require_once WPAIDA_DIR . 'includes/class-api.php';
require_once WPAIDA_DIR . 'includes/class-settings.php';
require_once WPAIDA_DIR . 'includes/class-admin.php';

add_action( 'plugins_loaded', function () {
    WPAIDA_Settings::init();
    WPAIDA_Admin::init();
} );
