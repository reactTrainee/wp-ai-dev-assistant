=== WP AI Dev Assistant ===
Contributors: wp-ai-dev-assistant
Tags: ai, wordpress, developer, debugging, claude
Requires at least: 6.4
Requires PHP: 7.4
Stable tag: 0.1.0
License: GPLv2 or later

AI-powered WordPress troubleshooting and developer assistance using the Claude API.

== Description ==

WP AI Dev Assistant is an early-stage developer tool that brings AI-assisted WordPress troubleshooting into the WordPress dashboard.

The MVP can analyze WordPress/PHP errors, debug information, code snippets, and technical questions.

== Installation ==

1. Upload the plugin ZIP through Plugins → Add New → Upload Plugin.
2. Activate the plugin.
3. Go to WP AI Dev Assistant → Settings.
4. Add your Claude API key.
5. Choose a current Anthropic model supported by your account.
6. Open WP AI Dev Assistant and submit a development problem.

== Security ==

The API key is stored server-side in WordPress and is never exposed to browser JavaScript. Administrators should use HTTPS and follow their organization's secret-management requirements.

Do not paste passwords, private keys, access tokens, customer personal data, or other secrets into the analysis box.

== External services ==

This plugin sends the text submitted by an administrator to the Anthropic Claude API to generate an AI response.

Service: Anthropic Claude API
URL: https://api.anthropic.com/

Review Anthropic's current terms, privacy documentation, and API documentation before production use.

== License ==

GPL-2.0-or-later
