# Installation

## Local WordPress

1. Zip the `wordpress-plugin/wp-ai-dev-assistant` directory.
2. In WordPress, open Plugins → Add New → Upload Plugin.
3. Upload the ZIP and activate it.
4. Open WP AI Dev Assistant → Settings.
5. Add your Anthropic API key.
6. Select a current Claude model supported by your account.
7. Test with a non-sensitive WordPress error.

## Important

Use HTTPS. Never paste API keys, passwords, database credentials, private keys, access tokens, or customer personal information into the analysis prompt.

The plugin is an MVP and should receive a security/privacy review before production deployment.
