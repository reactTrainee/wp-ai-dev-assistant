# Claude API integration

The MVP sends requests from WordPress PHP to Anthropic's Messages API.

Request path:

POST https://api.anthropic.com/v1/messages

The plugin sends:

- `x-api-key`
- `anthropic-version`
- JSON body containing model, max_tokens, system prompt, and user message.

The API key is deliberately not placed in browser JavaScript.

Keep the model ID configurable because Anthropic may introduce, update, or retire models over time.
